package A02_Queue;

public class QueueEmptyException extends Exception {

	private static final long serialVersionUID = 52034036L;

}
