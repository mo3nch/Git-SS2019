package A08_GraphZusammenh�ngend;

import basisAlgorithmen.Graph;

import java.util.Stack;

public class ConnectedComponents {

    public boolean[] visited;

    /**
     * Retourniert die Anzahl der zusammenh�ngenden Komponenten eines Graphen
     *
     * @param g zu pr�fender Graph
     * @return Anzahl der Komponenten
     */
    public int getNumberOfComponents(Graph g) {
        visited = new boolean[g.numVertices()];
        int countComponents = 0;
        Stack<Integer> stack = new Stack<>();

        for (int i = 0; i < g.numVertices(); i++) {
            if (!(getvisited(i))) {
                stack.push(i);
                setVisited(i);
                countComponents++;
            }
            while (!(stack.isEmpty())) {
                int temp = stack.pop();

                for (int j = 0; j < g.numVertices(); j++) {
                    if (temp != j) {
                        if (g.hasEdge(temp, j)) {
                            if (!(getvisited(j))) {
                                stack.push(j);
                                setVisited(j);
                            }
                        }
                    }

                }
            }

        }

        return countComponents;
    }

    public void setVisited(int num) {
        visited[num] = true;

    }

    public boolean getvisited(int num) {

        return visited[num];
    }


}
